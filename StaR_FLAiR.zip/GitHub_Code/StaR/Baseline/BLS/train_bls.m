function [train_acc, test_acc, train_time, test_time] = train_bls(trainX, trainY, testX, testY, params, seed, use_star)
rng(seed);
nclass = max([trainY; testY]) + 1;
Y = one_hot(trainY, nclass);

tic;
H1 = [trainX, 0.1 * ones(size(trainX, 1), 1)];
T1 = [testX, 0.1 * ones(size(testX, 1), 1)];
Z = [];
Z_test = [];

for i = 1:params.feature_windows
    We = 2 * rand(size(trainX, 2) + 1, params.feature_nodes) - 1;
    if use_star
        We = regulate_weights_using_StaR(We, params.sigma_high);
    end
    [block, block_min, block_scale] = minmax_fit_transform(H1 * We);
    Z = [Z, block];
    Z_test = [Z_test, minmax_transform(T1 * We, block_min, block_scale)];
end

H2 = [Z, 0.1 * ones(size(Z, 1), 1)];
H2_test = [Z_test, 0.1 * ones(size(Z_test, 1), 1)];
H = [];
H_test = [];

for i = 1:params.enhancement_windows
    Wh = orth(2 * rand(size(Z, 2) + 1, params.enhancement_nodes) - 1);
    if use_star
        Wh = regulate_weights_using_StaR(Wh, params.sigma_high);
    end
    H = [H, tanh(H2 * Wh)];
    H_test = [H_test, tanh(H2_test * Wh)];
end

features = [Z, H];
beta = ridge_solve(features, Y, params.C);
train_scores = features * beta;
train_time = toc;

tic;
test_scores = [Z_test, H_test] * beta;
test_time = toc;

train_acc = accuracy_from_scores(train_scores, trainY);
test_acc = accuracy_from_scores(test_scores, testY);
end

