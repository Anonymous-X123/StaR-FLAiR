function acc = accuracy_from_scores(scores, y)
[~, pred] = max(scores, [], 2);
pred = pred - 1;
acc = mean(pred == y) * 100;
end

