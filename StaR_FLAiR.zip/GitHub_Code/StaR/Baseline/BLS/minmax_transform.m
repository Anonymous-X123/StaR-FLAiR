function X_scaled = minmax_transform(X, x_min, x_scale)
X_scaled = -1 + 2 * ((X - x_min) ./ x_scale);
end

