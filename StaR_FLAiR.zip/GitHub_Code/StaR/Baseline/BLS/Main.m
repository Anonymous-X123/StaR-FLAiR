clear;
clc;
data_path = '../../../examples/toy_binary.csv';
seed = 42;
n_splits = 5;

params.C = 1.0;
params.feature_nodes = 10;
params.feature_windows = 5;
params.enhancement_nodes = 25;
params.enhancement_windows = 1;

% Paper search: C={10^-5,...,10^5}, feature nodes=5:5:50,
% feature windows={1,3,...,21}, enhancement nodes=5:10:105.
run_five_fold(data_path, @model_train, params, seed, n_splits);

