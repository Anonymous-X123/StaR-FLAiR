function Y = one_hot(y, nclass)
Y = zeros(numel(y), nclass);
for i = 1:numel(y)
    Y(i, y(i) + 1) = 1;
end
end

