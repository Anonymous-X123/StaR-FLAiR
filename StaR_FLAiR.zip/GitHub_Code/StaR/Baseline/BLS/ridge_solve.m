function beta = ridge_solve(X, Y, C)
[n_samples, n_features] = size(X);
if n_features < n_samples
    beta = (eye(n_features) / C + X' * X) \ (X' * Y);
else
    beta = X' * ((eye(n_samples) / C + X * X') \ Y);
end
end

