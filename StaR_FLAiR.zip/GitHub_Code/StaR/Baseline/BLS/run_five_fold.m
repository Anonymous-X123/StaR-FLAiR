function run_five_fold(data_path, modelFcn, params, seed, n_splits)
if nargin < 5
    n_splits = 5;
end

[X, y] = load_dataset(data_path);
All_data = [X, y];
length_train = size(All_data, 1);
block_size = length_train / (n_splits * 1.0);

train_acc = zeros(n_splits, 1);
test_acc = zeros(n_splits, 1);
train_time = zeros(n_splits, 1);
test_time = zeros(n_splits, 1);

fprintf('Data: %s\n', data_path);
fprintf('Seed: %d\n', seed);

part = 0;
while ceil((part + 1) * block_size) <= length_train
    if part == 0
        t_1 = ceil(part * block_size);
        t_2 = ceil((part + 1) * block_size);
        DataTest = All_data(t_1 + 1:t_2, :);
        DataTrain = All_data(t_2 + 1:length_train, :);
    elseif part == n_splits - 1
        t_1 = ceil(part * block_size);
        t_2 = ceil((part + 1) * block_size);
        DataTest = All_data(t_1 + 1:t_2, :);
        DataTrain = All_data(1:t_1, :);
    else
        t_1 = ceil(part * block_size);
        t_2 = ceil((part + 1) * block_size);
        DataTest = All_data(t_1 + 1:t_2, :);
        DataTrain = [All_data(1:t_1, :); All_data(t_2 + 1:length_train, :)];
    end

    fold = part + 1;
    trainX = DataTrain(:, 1:end-1);
    trainY = DataTrain(:, end);
    testX = DataTest(:, 1:end-1);
    testY = DataTest(:, end);

    [train_acc(fold), test_acc(fold), train_time(fold), test_time(fold)] = ...
        modelFcn(trainX, trainY, testX, testY, params, seed + fold);

    fprintf('Fold %d: train_acc=%.4f, test_acc=%.4f\n', fold, train_acc(fold), test_acc(fold));
    part = part + 1;
end

fprintf('Summary\n');
fprintf('Mean train accuracy (%%): %.4f\n', mean(train_acc));
fprintf('Std train accuracy (%%): %.4f\n', std(train_acc, 1));
fprintf('Mean test accuracy (%%): %.4f\n', mean(test_acc));
fprintf('Std test accuracy (%%): %.4f\n', std(test_acc, 1));
fprintf('Mean train time (s): %.6f\n', mean(train_time));
fprintf('Mean test time (s): %.6f\n', mean(test_time));
end
