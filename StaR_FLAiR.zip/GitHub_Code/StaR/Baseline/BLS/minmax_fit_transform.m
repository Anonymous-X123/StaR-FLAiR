function [X_scaled, x_min, x_scale] = minmax_fit_transform(X)
x_min = min(X, [], 1);
x_max = max(X, [], 1);
x_scale = x_max - x_min;
x_scale(x_scale == 0) = 1;
X_scaled = -1 + 2 * ((X - x_min) ./ x_scale);
end

