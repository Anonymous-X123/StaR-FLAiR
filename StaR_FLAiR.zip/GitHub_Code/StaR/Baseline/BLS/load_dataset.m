function [X, y] = load_dataset(data_path)
[~, ~, ext] = fileparts(data_path);
if strcmpi(ext, '.mat')
    raw = load(data_path);
    names = fieldnames(raw);
    best_name = names{1};
    best_size = 0;
    for i = 1:numel(names)
        value = raw.(names{i});
        if isnumeric(value) && ismatrix(value) && numel(value) > best_size
            best_name = names{i};
            best_size = numel(value);
        end
    end
    data = raw.(best_name);
else
    data = readmatrix(data_path);
end

labels = data(:, end);
labels(labels == -1) = 0;
X = zscore(data(:, 1:end-1)')';
[~, ~, y] = unique(labels);
y = y - 1;
end
