clear;
clc;
data_path = '../../../examples/toy_binary.csv';
seed = 42;
n_splits = 5;

params.C = 1.0;
params.hidden_nodes = 103;
params.activation = 6;

% Paper search: C={10^-5,...,10^5}, hidden nodes=3:20:203,
% activations={1(sigmoid),2(sine),3(tribas),4(radbas),5(tansig),6(relu)}.
run_five_fold(data_path, @model_train, params, seed, n_splits);

