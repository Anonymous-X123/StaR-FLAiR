function H = activation_fn(Z, activation)
switch activation
    case 1
        H = 1 ./ (1 + exp(-Z));
    case 2
        H = sin(Z);
    case 3
        H = max(0, 1 - abs(Z));
    case 4
        H = exp(-(Z .^ 2));
    case 5
        H = tanh(Z);
    case 6
        H = max(0, Z);
    otherwise
        error('Unknown activation function. Use 1=sigmoid, 2=sine, 3=tribas, 4=radbas, 5=tansig, or 6=relu.');
end
end
