function [train_acc, test_acc, train_time, test_time] = train_shallow(trainX, trainY, testX, testY, params, seed, model_type, use_star)
rng(seed);
nclass = max([trainY; testY]) + 1;
Y = one_hot(trainY, nclass);
[n_samples, n_features] = size(trainX);

tic;
W = 2 * rand(n_features, params.hidden_nodes) - 1;
if use_star
    W = regulate_weights_using_StaR(W, params.sigma_high);
end
b = rand(1, params.hidden_nodes);
H = activation_fn(trainX * W + repmat(b, n_samples, 1), params.activation);

if strcmpi(model_type, 'rvfl')
    features = [trainX, H, ones(n_samples, 1)];
else
    features = [H, ones(n_samples, 1)];
end

beta = ridge_solve(features, Y, params.C);
train_scores = features * beta;
train_time = toc;

tic;
H_test = activation_fn(testX * W + repmat(b, size(testX, 1), 1), params.activation);
if strcmpi(model_type, 'rvfl')
    test_features = [testX, H_test, ones(size(testX, 1), 1)];
else
    test_features = [H_test, ones(size(testX, 1), 1)];
end
test_scores = test_features * beta;
test_time = toc;

train_acc = accuracy_from_scores(train_scores, trainY);
test_acc = accuracy_from_scores(test_scores, testY);
end

