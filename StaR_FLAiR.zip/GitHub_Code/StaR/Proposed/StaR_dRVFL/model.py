from rnn_models import run_cross_validation, train_drvfl


def fixed_parameters():
    # Paper search: C={10^-5,...,10^5}, hidden nodes from the dRVFL grid,
    # layers=1:10, scale=2^[-1:0.5:2], activations={sigmoid,relu,selu},
    # sigma_high={0.5,0.75,1.0,1.25,1.5,1.75,2.0}.
    return {
        "c": 1.0,
        "hidden_nodes": 256,
        "layers": 2,
        "scale": 1.0,
        "activation": "relu",
        "sigma_high": 1.0,
    }


def train(train_x, train_y, test_x, test_y, params, seed):
    return train_drvfl(train_x, train_y, test_x, test_y, params, seed=seed, use_star=True)


def run(argv=None):
    run_cross_validation(train, fixed_parameters(), argv)

