function [train_acc, test_acc, train_time, test_time] = model_train(trainX, trainY, testX, testY, params, seed)
[train_acc, test_acc, train_time, test_time] = train_bls(trainX, trainY, testX, testY, params, seed, true);
end

