function W = regulate_weights_using_StaR(W_init, sigma_high)
sigma_low = 0.1 * sigma_high;
[U, S, V] = svd(W_init, 'econ');
s = diag(S);
s_scaled = (s - min(s)) ./ (max(s) - min(s) + eps);
s_scaled = s_scaled .* (sigma_high - sigma_low) + sigma_low;
W = U * diag(s_scaled) * V';
end

