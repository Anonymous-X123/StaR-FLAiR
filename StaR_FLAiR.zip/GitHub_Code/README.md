# StaR and FLAiR Code

This repository contains reference implementations for the manuscript "Spectral Stability and Task-Adaptive Initialization for Randomized Neural Networks".

The code is organized by method family and model type. MATLAB models are provided as MATLAB code, and Python models are provided as Python code. Each model folder is self-contained.

## Folder Structure

```text
StaR/
  Baseline/
    ELM/          MATLAB
    RVFL/         MATLAB
    BLS/          MATLAB
    dRVFL/        Python
  Proposed/
    StaR_ELM/     MATLAB
    StaR_RVFL/    MATLAB
    StaR_BLS/     MATLAB
    StaR_dRVFL/   Python

FLAiR/
  Baseline/
    ELM/          Python
    RVFL/         Python
    BLS/          Python
    dRVFL/        Python
  Proposed/
    FLAiR_ELM/    Python
    FLAiR_RVFL/   Python
    FLAiR_BLS/    Python
    FLAiR_dRVFL/  Python
```

## Data Format

Datasets should be stored as `.csv`, `.txt`, or `.mat` files. The class label should be in the last column by default.

For Python `.mat` files, use `--mat-key` if the file contains multiple variables:

```bash
python main.py --data ../../../examples/toy_binary.mat --mat-key data
```

For MATLAB `.mat` files, the loader selects the largest two-dimensional numeric array.

## Running MATLAB Models

Open MATLAB in the desired model folder and run:

```matlab
Main
```

Edit `data_path` inside `Main.m` to point to your dataset.

## Running Python Models

Install dependencies:

```bash
pip install -r requirements.txt
```

Run a model from its folder:

```bash
python main.py --data ../../../examples/toy_binary.csv
```

Example:

```bash
cd FLAiR/Proposed/FLAiR_RVFL
python main.py --data ../../../examples/toy_binary.csv
```

## Experimental Setup

This scripts use fixed hyperparameter values for simple execution. To reproduce manuscript-style results, follow the same experimental setup described in Section S.V of the supplementary manuscript.

In brief, the original experimental protocol is:

- Normalize the full feature matrix to zero mean and unit variance.
- Use 5-fold contiguous block cross-validation in dataset order.
- Use the class label in the final column.
- Report the mean and standard deviation of train/test accuracy across the five folds.
- Use the full hyperparameter search ranges listed below.

The default seed in the public scripts is `42`.

## Hyperparameter Ranges

Regularization parameter for all models:

```text
C in {10^-5, 10^-4, ..., 10^4, 10^5}
```

ELM and RVFL:

```text
Hidden nodes: {3, 23, 43, ..., 203}
Activation: 1=sigmoid, 2=sine, 3=tribas, 4=radbas, 5=tansig, 6=relu
```

BLS:

```text
Feature nodes per window: {5, 10, ..., 50}
Feature windows: {1, 3, 5, ..., 21}
Enhancement nodes: {5, 15, 25, ..., 105}
Enhancement windows: 1
```

dRVFL:

```text
Layers: {1, 2, ..., 10}
Scale: 2^{ -1, -0.5, 0, 0.5, 1, 1.5, 2 }
Activation: 1=sigmoid, 2=relu, 3=selu
Hidden nodes: {256, 512, 1024} for smaller datasets; {1024, 2048, 4096} for larger datasets
Fine adjustment factors for C and hidden nodes: {0.9, 0.95, 1.0, 1.05, 1.1}
```

StaR variants:

```text
sigma_high in {0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0}
sigma_low = 0.1 * sigma_high
```

FLAiR variants:

```text
Warm-up epochs: {2, 4, 6, 8, 10}
Optimizer: Adam during the warm-up phase
```

## Notes

- The code is intended to provide transparent, executable implementations aligned with the manuscript.
- Each model folder can be copied and run independently.
- For exact reported results, use the full hyperparameter search and experimental protocol described in Section S.V of the supplementary manuscript.
