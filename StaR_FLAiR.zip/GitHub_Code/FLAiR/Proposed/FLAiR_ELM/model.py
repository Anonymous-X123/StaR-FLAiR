from rnn_models import run_cross_validation, train_shallow


def fixed_parameters():
    # Paper search: C={10^-5,...,10^5}, hidden nodes=3:20:203,
    # activations={1(sigmoid),2(sine),3(tribas),4(radbas),5(tansig),6(relu)},
    # warm-up epochs={2,4,6,8,10}.
    return {
        "c": 1.0,
        "hidden_nodes": 103,
        "activation": 6,
        "warmup_epochs": 4,
        "learning_rate": 0.01,
    }


def train(train_x, train_y, test_x, test_y, params, seed):
    return train_shallow(train_x, train_y, test_x, test_y, params, "elm", seed=seed, use_flair=True)


def run(argv=None):
    run_cross_validation(train, fixed_parameters(), argv)

