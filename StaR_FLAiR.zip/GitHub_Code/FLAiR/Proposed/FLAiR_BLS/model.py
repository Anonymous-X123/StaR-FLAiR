from rnn_models import run_cross_validation, train_bls


def fixed_parameters():
    # Paper search: C={10^-5,...,10^5}, feature nodes=5:5:50,
    # feature windows={1,3,...,21}, enhancement nodes=5:10:105,
    # warm-up epochs={2,4,6,8,10}.
    return {
        "c": 1.0,
        "feature_nodes": 10,
        "feature_windows": 5,
        "enhancement_nodes": 25,
        "enhancement_windows": 1,
        "warmup_epochs": 4,
        "learning_rate": 0.01,
    }


def train(train_x, train_y, test_x, test_y, params, seed):
    return train_bls(train_x, train_y, test_x, test_y, params, seed=seed, use_flair=True)


def run(argv=None):
    run_cross_validation(train, fixed_parameters(), argv)

