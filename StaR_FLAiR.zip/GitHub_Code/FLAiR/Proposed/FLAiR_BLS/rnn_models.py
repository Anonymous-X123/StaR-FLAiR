import argparse
import time
from dataclasses import dataclass

import numpy as np


@dataclass
class Result:
    train_accuracy: float
    test_accuracy: float
    train_time: float
    test_time: float


def load_table(path, label_column=-1, mat_key=None):
    if path.lower().endswith(".mat"):
        try:
            import scipy.io
        except ImportError as exc:
            raise ImportError("Loading MAT files requires scipy. Install it with: pip install scipy") from exc
        data = scipy.io.loadmat(path)
        if mat_key is None:
            arrays = [
                value for key, value in data.items()
                if not key.startswith("__") and isinstance(value, np.ndarray) and value.ndim == 2
            ]
            if not arrays:
                raise ValueError("No two-dimensional array found in MAT file.")
            table = max(arrays, key=lambda item: item.size)
        else:
            table = data[mat_key]
    else:
        delimiter = "," if path.lower().endswith(".csv") else None
        table = np.loadtxt(path, delimiter=delimiter)

    if label_column != -1:
        table = np.hstack((np.delete(table, label_column, axis=1), table[:, [label_column]]))

    x = table[:, :-1].astype(float)
    mean = x.mean(axis=0, keepdims=True)
    std = x.std(axis=0, keepdims=True)
    std = np.where(std == 0.0, 1.0, std)
    x = (x - mean) / std
    labels = table[:, -1]
    labels = np.where(labels == -1, 0, labels)
    _, y = np.unique(labels, return_inverse=True)
    return x, y


def make_folds(x, y, n_splits=5, seed=42):
    n_samples = len(y)
    block_size = n_samples // n_splits
    all_indices = np.arange(n_samples)
    for part in range(n_splits):
        start = part * block_size
        stop = (part + 1) * block_size
        test_idx = np.arange(start, stop)
        train_idx = np.setdiff1d(all_indices, test_idx, assume_unique=True)
        yield part + 1, x[train_idx], y[train_idx], x[test_idx], y[test_idx]


def one_hot(y, n_classes):
    targets = np.zeros((len(y), n_classes), dtype=float)
    targets[np.arange(len(y)), y.astype(int)] = 1.0
    return targets


def ridge_solve(features, targets, c):
    n_samples, n_features = features.shape
    if n_features < n_samples:
        return np.linalg.solve(np.eye(n_features) / c + features.T @ features, features.T @ targets)
    return features.T @ np.linalg.solve(np.eye(n_samples) / c + features @ features.T, targets)


def accuracy(scores, y):
    return float(np.mean(np.argmax(scores, axis=1) == y) * 100.0)


def adam_update(param, grad, state, epoch, lr, beta1=0.9, beta2=0.999, eps=1e-8):
    m, v = state
    m = beta1 * m + (1.0 - beta1) * grad
    v = beta2 * v + (1.0 - beta2) * (grad ** 2)
    m_hat = m / (1.0 - beta1 ** epoch)
    v_hat = v / (1.0 - beta2 ** epoch)
    return param - lr * m_hat / (np.sqrt(v_hat) + eps), (m, v)


def minmax_fit_transform(x):
    x_min = x.min(axis=0, keepdims=True)
    x_max = x.max(axis=0, keepdims=True)
    scale = np.where((x_max - x_min) == 0.0, 1.0, x_max - x_min)
    return -1.0 + 2.0 * (x - x_min) / scale, x_min, scale


def minmax_transform(x, x_min, scale):
    return -1.0 + 2.0 * (x - x_min) / scale


def orth_columns(x):
    u, singular_values, _ = np.linalg.svd(x, full_matrices=False)
    tol = np.finfo(float).eps * max(x.shape) * singular_values.max()
    return u[:, singular_values > tol]


def train_bls(train_x, train_y, test_x, test_y, params, seed=42, use_flair=True):
    rng = np.random.default_rng(seed)
    n_classes = int(max(train_y.max(), test_y.max()) + 1)
    targets = one_hot(train_y, n_classes)
    c = params["c"]
    n1 = params["feature_nodes"]
    n2 = params["feature_windows"]
    n3 = params["enhancement_nodes"]
    n4 = params["enhancement_windows"]

    start = time.perf_counter()
    h1 = np.hstack((train_x, 0.1 * np.ones((train_x.shape[0], 1))))
    t1 = np.hstack((test_x, 0.1 * np.ones((test_x.shape[0], 1))))
    feature_weights = [rng.uniform(-1.0, 1.0, size=(train_x.shape[1] + 1, n1)) for _ in range(n2)]
    states = [(np.zeros_like(w), np.zeros_like(w)) for w in feature_weights]
    for epoch in range(1, params["warmup_epochs"] + 1):
        blocks = [minmax_fit_transform(h1 @ w)[0] for w in feature_weights]
        z = np.hstack(blocks)
        beta = ridge_solve(z, targets, c)
        err = z @ beta - targets
        for idx in range(n2):
            block_beta = beta[idx * n1:(idx + 1) * n1, :]
            grad = h1.T @ (err @ block_beta.T) / train_x.shape[0]
            feature_weights[idx], states[idx] = adam_update(feature_weights[idx], grad, states[idx], epoch, params["learning_rate"])

    z_blocks, z_test_blocks = [], []
    for weights in feature_weights:
        block, block_min, block_scale = minmax_fit_transform(h1 @ weights)
        z_blocks.append(block)
        z_test_blocks.append(minmax_transform(t1 @ weights, block_min, block_scale))
    z = np.hstack(z_blocks)
    z_test = np.hstack(z_test_blocks)

    h2 = np.hstack((z, 0.1 * np.ones((z.shape[0], 1))))
    h2_test = np.hstack((z_test, 0.1 * np.ones((z_test.shape[0], 1))))
    enhancement_weights = []
    for _ in range(n4):
        raw = rng.uniform(-1.0, 1.0, size=(n1 * n2 + 1, n3))
        enhancement_weights.append(orth_columns(raw))

    states = [(np.zeros_like(w), np.zeros_like(w)) for w in enhancement_weights]
    for epoch in range(1, params["warmup_epochs"] + 1):
        hidden_blocks = [np.tanh(h2 @ w) for w in enhancement_weights]
        hidden = np.hstack(hidden_blocks)
        features = np.hstack((z, hidden))
        beta = ridge_solve(features, targets, c)
        err = features @ beta - targets
        for idx in range(n4):
            start_idx = z.shape[1] + idx * n3
            block_beta = beta[start_idx:start_idx + n3, :]
            raw = h2 @ enhancement_weights[idx]
            grad = h2.T @ ((err @ block_beta.T) * (1.0 - np.tanh(raw) ** 2)) / train_x.shape[0]
            enhancement_weights[idx], states[idx] = adam_update(enhancement_weights[idx], grad, states[idx], epoch, params["learning_rate"])

    hidden = np.hstack([np.tanh(h2 @ w) for w in enhancement_weights])
    features = np.hstack((z, hidden))
    beta = ridge_solve(features, targets, c)
    train_scores = features @ beta
    train_time = time.perf_counter() - start

    start = time.perf_counter()
    hidden_test = np.hstack([np.tanh(h2_test @ w) for w in enhancement_weights])
    test_scores = np.hstack((z_test, hidden_test)) @ beta
    test_time = time.perf_counter() - start
    return Result(accuracy(train_scores, train_y), accuracy(test_scores, test_y), train_time, test_time)


def run_cross_validation(model_function, params, argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--label-column", type=int, default=-1)
    parser.add_argument("--mat-key", default=None)
    args = parser.parse_args(argv)

    x, y = load_table(args.data, label_column=args.label_column, mat_key=args.mat_key)
    results = []
    print(f"Data: {args.data}")
    print(f"Seed: {args.seed}")
    for fold_id, train_x, train_y, test_x, test_y in make_folds(x, y, args.folds, args.seed):
        result = model_function(train_x, train_y, test_x, test_y, params, args.seed + fold_id)
        results.append(result)
        print(f"Fold {fold_id}: train_acc={result.train_accuracy:.4f}, test_acc={result.test_accuracy:.4f}")

    train_acc = np.array([item.train_accuracy for item in results])
    test_acc = np.array([item.test_accuracy for item in results])
    train_time = np.array([item.train_time for item in results])
    test_time = np.array([item.test_time for item in results])
    print("Summary")
    print(f"Mean train accuracy (%): {train_acc.mean():.4f}")
    print(f"Std train accuracy (%): {train_acc.std(ddof=0):.4f}")
    print(f"Mean test accuracy (%): {test_acc.mean():.4f}")
    print(f"Std test accuracy (%): {test_acc.std(ddof=0):.4f}")
    print(f"Mean train time (s): {train_time.mean():.6f}")
    print(f"Mean test time (s): {test_time.mean():.6f}")
