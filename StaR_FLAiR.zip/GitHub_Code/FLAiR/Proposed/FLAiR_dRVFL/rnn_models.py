import argparse
import time
from dataclasses import dataclass

import numpy as np


@dataclass
class Result:
    train_accuracy: float
    test_accuracy: float
    train_time: float
    test_time: float


def load_table(path, label_column=-1, mat_key=None):
    if path.lower().endswith(".mat"):
        try:
            import scipy.io
        except ImportError as exc:
            raise ImportError("Loading MAT files requires scipy. Install it with: pip install scipy") from exc
        data = scipy.io.loadmat(path)
        if mat_key is None:
            arrays = [
                value for key, value in data.items()
                if not key.startswith("__") and isinstance(value, np.ndarray) and value.ndim == 2
            ]
            if not arrays:
                raise ValueError("No two-dimensional array found in MAT file.")
            table = max(arrays, key=lambda item: item.size)
        else:
            table = data[mat_key]
    else:
        delimiter = "," if path.lower().endswith(".csv") else None
        table = np.loadtxt(path, delimiter=delimiter)

    if label_column != -1:
        table = np.hstack((np.delete(table, label_column, axis=1), table[:, [label_column]]))

    x = table[:, :-1].astype(float)
    mean = x.mean(axis=0, keepdims=True)
    std = x.std(axis=0, keepdims=True)
    std = np.where(std == 0.0, 1.0, std)
    x = (x - mean) / std
    labels = table[:, -1]
    labels = np.where(labels == -1, 0, labels)
    _, y = np.unique(labels, return_inverse=True)
    return x, y


def make_folds(x, y, n_splits=5, seed=42):
    n_samples = len(y)
    block_size = n_samples // n_splits
    all_indices = np.arange(n_samples)
    for part in range(n_splits):
        start = part * block_size
        stop = (part + 1) * block_size
        test_idx = np.arange(start, stop)
        train_idx = np.setdiff1d(all_indices, test_idx, assume_unique=True)
        yield part + 1, x[train_idx], y[train_idx], x[test_idx], y[test_idx]


def standardize_fit_transform(x):
    mean = x.mean(axis=0, keepdims=True)
    std = x.std(axis=0, keepdims=True)
    std = np.where(std == 0.0, 1.0, std)
    return (x - mean) / std, mean, std


def one_hot(y, n_classes):
    targets = np.zeros((len(y), n_classes), dtype=float)
    targets[np.arange(len(y)), y.astype(int)] = 1.0
    return targets


def ridge_solve(features, targets, c):
    n_samples, n_features = features.shape
    if n_features < n_samples:
        return np.linalg.solve(np.eye(n_features) / c + features.T @ features, features.T @ targets)
    return features.T @ np.linalg.solve(np.eye(n_samples) / c + features @ features.T, targets)


def accuracy(scores, y):
    return float(np.mean(np.argmax(scores, axis=1) == y) * 100.0)


def activation(z, name):
    if name == 1 or name == "sigmoid":
        return 1.0 / (1.0 + np.exp(-z))
    if name == 2 or name == "sine":
        return np.sin(z)
    if name == 3 or name == "tribas":
        return np.maximum(0.0, 1.0 - np.abs(z))
    if name == 4 or name == "radbas":
        return np.exp(-(z ** 2))
    if name == 5 or name == "tansig":
        return np.tanh(z)
    if name == 6 or name == "relu":
        return np.maximum(0.0, z)
    if name == "selu":
        return 1.0507 * np.where(z > 0.0, z, 1.67326 * (np.exp(z) - 1.0))
    raise ValueError(f"Unknown activation: {name}")


def activation_grad(z, name):
    if name == 1 or name == "sigmoid":
        a = activation(z, name)
        return a * (1.0 - a)
    if name == 2 or name == "sine":
        return np.cos(z)
    if name == 3 or name == "tribas":
        return np.where(np.abs(z) < 1.0, -np.sign(z), 0.0)
    if name == 4 or name == "radbas":
        a = activation(z, name)
        return -2.0 * z * a
    if name == 5 or name == "tansig":
        a = np.tanh(z)
        return 1.0 - a ** 2
    if name == 6 or name == "relu":
        return (z > 0.0).astype(float)
    if name == "selu":
        return 1.0507 * np.where(z > 0.0, 1.0, 1.67326 * np.exp(z))
    raise ValueError(f"Unknown activation: {name}")


def adam_update(param, grad, state, epoch, lr, beta1=0.9, beta2=0.999, eps=1e-8):
    m, v = state
    m = beta1 * m + (1.0 - beta1) * grad
    v = beta2 * v + (1.0 - beta2) * (grad ** 2)
    m_hat = m / (1.0 - beta1 ** epoch)
    v_hat = v / (1.0 - beta2 ** epoch)
    return param - lr * m_hat / (np.sqrt(v_hat) + eps), (m, v)


def train_drvfl(train_x, train_y, test_x, test_y, params, seed=42, use_flair=True):
    rng = np.random.default_rng(seed)
    n_classes = int(max(train_y.max(), test_y.max()) + 1)
    targets = one_hot(train_y, n_classes)
    c = params["c"]
    n_hidden = params["hidden_nodes"]
    n_layers = params["layers"]
    scale = params["scale"]
    act = params["activation"]

    start = time.perf_counter()
    weights, biases = [], []
    in_dim = train_x.shape[1]
    for _ in range(n_layers):
        weights.append(scale * rng.uniform(-1.0, 1.0, size=(in_dim, n_hidden)))
        biases.append(scale * rng.uniform(0.0, 1.0, size=(1, n_hidden)))
        in_dim = n_hidden

    states_w = [(np.zeros_like(w), np.zeros_like(w)) for w in weights]
    states_b = [(np.zeros_like(b), np.zeros_like(b)) for b in biases]
    for epoch in range(1, params["warmup_epochs"] + 1):
        acts = [train_x]
        linears = []
        current = train_x
        for idx in range(n_layers):
            linear = current @ weights[idx] + biases[idx]
            current = activation(linear, act)
            linears.append(linear)
            acts.append(current)
        features = np.hstack(acts + [np.ones((train_x.shape[0], 1))])
        beta = ridge_solve(features, targets, c)
        err = features @ beta - targets
        offset = train_x.shape[1]
        grad_next = None
        for idx in reversed(range(n_layers)):
            block_beta = beta[offset + idx * n_hidden:offset + (idx + 1) * n_hidden, :]
            grad_feature = err @ block_beta.T
            if grad_next is not None:
                grad_feature = grad_feature + grad_next @ weights[idx + 1].T
            grad_linear = grad_feature * activation_grad(linears[idx], act)
            grad_w = acts[idx].T @ grad_linear / train_x.shape[0]
            grad_b = grad_linear.mean(axis=0, keepdims=True)
            weights[idx], states_w[idx] = adam_update(weights[idx], grad_w, states_w[idx], epoch, params["learning_rate"])
            biases[idx], states_b[idx] = adam_update(biases[idx], grad_b, states_b[idx], epoch, params["learning_rate"])
            grad_next = grad_linear

    train_blocks, test_blocks = [train_x], [test_x]
    current_train, current_test = train_x, test_x
    for idx in range(n_layers):
        current_train = current_train @ weights[idx] + biases[idx]
        current_test = current_test @ weights[idx] + biases[idx]
        current_train, mean, std = standardize_fit_transform(current_train)
        current_test = (current_test - mean) / std
        current_train = activation(current_train, act)
        current_test = activation(current_test, act)
        train_blocks.append(current_train)
        test_blocks.append(current_test)

    features = np.hstack(train_blocks + [np.ones((train_x.shape[0], 1))])
    beta = ridge_solve(features, targets, c)
    train_scores = features @ beta
    train_time = time.perf_counter() - start

    start = time.perf_counter()
    test_scores = np.hstack(test_blocks + [np.ones((test_x.shape[0], 1))]) @ beta
    test_time = time.perf_counter() - start
    return Result(accuracy(train_scores, train_y), accuracy(test_scores, test_y), train_time, test_time)


def run_cross_validation(model_function, params, argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--label-column", type=int, default=-1)
    parser.add_argument("--mat-key", default=None)
    args = parser.parse_args(argv)

    x, y = load_table(args.data, label_column=args.label_column, mat_key=args.mat_key)
    results = []
    print(f"Data: {args.data}")
    print(f"Seed: {args.seed}")
    for fold_id, train_x, train_y, test_x, test_y in make_folds(x, y, args.folds, args.seed):
        result = model_function(train_x, train_y, test_x, test_y, params, args.seed + fold_id)
        results.append(result)
        print(f"Fold {fold_id}: train_acc={result.train_accuracy:.4f}, test_acc={result.test_accuracy:.4f}")

    train_acc = np.array([item.train_accuracy for item in results])
    test_acc = np.array([item.test_accuracy for item in results])
    train_time = np.array([item.train_time for item in results])
    test_time = np.array([item.test_time for item in results])
    print("Summary")
    print(f"Mean train accuracy (%): {train_acc.mean():.4f}")
    print(f"Std train accuracy (%): {train_acc.std(ddof=0):.4f}")
    print(f"Mean test accuracy (%): {test_acc.mean():.4f}")
    print(f"Std test accuracy (%): {test_acc.std(ddof=0):.4f}")
    print(f"Mean train time (s): {train_time.mean():.6f}")
    print(f"Mean test time (s): {test_time.mean():.6f}")
