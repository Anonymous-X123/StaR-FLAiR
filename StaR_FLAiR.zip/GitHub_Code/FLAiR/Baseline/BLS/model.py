from rnn_models import run_cross_validation, train_bls


def fixed_parameters():
    # Paper search: C={10^-5,...,10^5}, feature nodes=5:5:50,
    # feature windows={1,3,...,21}, enhancement nodes=5:10:105.
    return {
        "c": 1.0,
        "feature_nodes": 10,
        "feature_windows": 5,
        "enhancement_nodes": 25,
        "enhancement_windows": 1,
    }


def train(train_x, train_y, test_x, test_y, params, seed):
    return train_bls(train_x, train_y, test_x, test_y, params, seed=seed)


def run(argv=None):
    run_cross_validation(train, fixed_parameters(), argv)

