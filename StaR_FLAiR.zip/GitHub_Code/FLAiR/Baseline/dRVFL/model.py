from rnn_models import run_cross_validation, train_drvfl


def fixed_parameters():
    # Paper search: C={10^-5,...,10^5}, hidden nodes from the dRVFL grid,
    # layers=1:10, scale=2^[-1:0.5:2], activations={sigmoid,relu,selu}.
    return {
        "c": 1.0,
        "hidden_nodes": 256,
        "layers": 2,
        "scale": 1.0,
        "activation": "relu",
    }


def train(train_x, train_y, test_x, test_y, params, seed):
    return train_drvfl(train_x, train_y, test_x, test_y, params, seed=seed)


def run(argv=None):
    run_cross_validation(train, fixed_parameters(), argv)

